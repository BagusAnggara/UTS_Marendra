package com.example.app_event

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
