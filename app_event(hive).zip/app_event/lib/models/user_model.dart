import 'package:hive/hive.dart';

part 'user_model.g.dart';

@HiveType(typeId: 0)
class User extends HiveObject {
  @HiveField(0)
  late String userId;

  @HiveField(1)
  late String username;

  @HiveField(2)
  late String fullName;

  @HiveField(3)
  late String nim;

  @HiveField(4)
  late String phone;

  @HiveField(5)
  late String password;
}
