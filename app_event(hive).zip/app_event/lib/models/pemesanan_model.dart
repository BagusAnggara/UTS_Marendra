import 'package:hive/hive.dart';

part 'pemesanan_model.g.dart';

@HiveType(typeId: 2)
class Pemesanan extends HiveObject {
  @HiveField(0)
  late String pemesananId;

  @HiveField(1)
  late String userId;

  @HiveField(2)
  late String eventId;

  @HiveField(3)
  late DateTime bookingDate;

  @HiveField(4)
  late String status;
}
