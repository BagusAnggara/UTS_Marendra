import 'package:hive/hive.dart';

part 'event_model.g.dart';

@HiveType(typeId: 1)
class Event extends HiveObject {
  @HiveField(0)
  late String eventId;

  @HiveField(1)
  late String eventName;

  @HiveField(2)
  late String eventDate;

  @HiveField(3)
  late String eventLocation;

  @HiveField(4)
  late String eventPoster;

  @HiveField(5)
  late String eventDescription;

  @HiveField(6)
  late String eventCategory;
}
