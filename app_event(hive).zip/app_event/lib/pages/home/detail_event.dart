import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';
import '../../models/event_model.dart';
import '../../models/pemesanan_model.dart';
import '../../dao/pemesanan_dao.dart';

class DetailEventPage extends StatelessWidget {
  final Event event;
  final PemesananDao pemesananDao = PemesananDao();

  DetailEventPage({required this.event});

  Future<void> _checkout(BuildContext context) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString('userId');

    if (userId != null) {
      Pemesanan pemesanan = Pemesanan()
        ..pemesananId = Uuid().v4()
        ..userId = userId
        ..eventId = event.eventId
        ..bookingDate = DateTime.now()
        ..status = 'Pending';

      await pemesananDao.addPemesanan(pemesanan);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Checkout berhasil!')),
      );

      // Navigasi ke halaman pemesanan atau dashboard setelah checkout berhasil
      Navigator.pushReplacementNamed(context, '/home');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('User tidak ditemukan. Silakan login kembali.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          event.eventName,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 22,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.deepPurple,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              if (event.eventPoster != null && event.eventPoster.isNotEmpty)
                ClipRRect(
                  borderRadius: BorderRadius.circular(10.0),
                  child: Image.network(
                    event.eventPoster,
                    height: 200,
                    width: double.infinity,
                    fit: BoxFit.cover,
                  ),
                ),
              SizedBox(height: 20),
              Text(
                event.eventName,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.deepPurple,
                ),
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  Icon(Icons.calendar_today, color: Colors.deepPurple),
                  SizedBox(width: 5),
                  Text(
                    event.eventDate,
                    style: TextStyle(fontSize: 18, color: Colors.grey[700]),
                  ),
                ],
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  Icon(Icons.location_on, color: Colors.deepPurple),
                  SizedBox(width: 5),
                  Text(
                    event.eventLocation,
                    style: TextStyle(fontSize: 18, color: Colors.grey[700]),
                  ),
                ],
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  Icon(Icons.category, color: Colors.deepPurple),
                  SizedBox(width: 5),
                  Text(
                    event.eventCategory,
                    style: TextStyle(fontSize: 18, color: Colors.grey[700]),
                  ),
                ],
              ),
              SizedBox(height: 10),
              Text(
                event.eventDescription,
                style: TextStyle(fontSize: 16, color: Colors.grey[800]),
              ),
              SizedBox(height: 20),
              Center(
                child: ElevatedButton.icon(
                  onPressed: () {
                    _checkout(context);
                  },
                  icon: Icon(Icons.shopping_cart),
                  label: Text('Checkout'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.symmetric(horizontal: 30, vertical: 15),
                    textStyle: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
