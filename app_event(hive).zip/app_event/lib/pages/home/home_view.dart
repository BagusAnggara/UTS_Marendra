import 'package:flutter/material.dart';
import '../../dao/event_dao.dart';
import '../../dao/pemesanan_dao.dart';
import '../../dao/user_dao.dart';
import '../../models/event_model.dart';
import '../../models/pemesanan_model.dart';
import '../../models/user_model.dart';
import 'detail_event.dart';

class HomeView extends StatefulWidget {
  @override
  _HomeViewState createState() => _HomeViewState();
}

class _HomeViewState extends State<HomeView> {
  int _currentIndex = 0;
  final EventDao eventDao = EventDao();
  final PemesananDao pemesananDao = PemesananDao();
  final UserDao userDao = UserDao();
  List<Event> filteredEvents = [];
  List<Pemesanan> filteredOrders = [];
  List<Event> events = [];
  List<User> users = [];

  @override
  void initState() {
    super.initState();
    _refreshData();
  }

  Future<void> _refreshData() async {
    events = eventDao.getAllEvents();
    users = userDao.getAllUsers();
    setState(() {
      filteredEvents = events;
      filteredOrders = pemesananDao.getAllPemesanans();
    });
  }

  void filterEvents(String category, DateTime? date) {
    setState(() {
      filteredEvents = events.where((event) {
        final matchesCategory = category.isEmpty ||
            event.eventCategory.toLowerCase().contains(category.toLowerCase());
        final matchesDate =
            date == null || event.eventDate == date.toString().split(' ')[0];
        return matchesCategory && matchesDate;
      }).toList();
    });
  }

  void filterOrders(String category, DateTime? date) {
    setState(() {
      filteredOrders = pemesananDao.getAllPemesanans().where((order) {
        final matchesCategory =
            category.isEmpty || order.eventId.contains(category);
        final matchesDate = date == null || isSameDate(order.bookingDate, date);
        return matchesCategory && matchesDate;
      }).toList();
    });
  }

  bool isSameDate(DateTime date1, DateTime date2) {
    return date1.year == date2.year &&
        date1.month == date2.month &&
        date1.day == date2.day;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.purple, Colors.deepPurple],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        title: Text(
          _currentIndex == 0 ? 'Event' : 'Order',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 22,
            color: Colors.white,
          ),
        ),
        centerTitle: true,
        elevation: 10,
        shadowColor: Colors.deepPurple.withOpacity(0.5),
      ),
      body: _currentIndex == 0
          ? EventView(
              filteredEvents: filteredEvents,
              onFilter: filterEvents,
              onRefresh: _refreshData)
          : OrderView(
              filteredOrders: filteredOrders,
              events: events,
              users: users,
              onFilter: filterOrders,
              pemesananDao: pemesananDao,
              onRefresh: _refreshData,
            ),
      bottomNavigationBar: Container(
        margin: EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(20),
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: BottomNavigationBar(
            backgroundColor: Colors.deepPurple,
            currentIndex: _currentIndex,
            onTap: (index) {
              setState(() {
                _currentIndex = index;
              });
            },
            selectedItemColor: Colors.white,
            unselectedItemColor: Colors.grey,
            items: const [
              BottomNavigationBarItem(
                icon: Icon(Icons.event),
                label: 'Event',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.list),
                label: 'Order',
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class EventView extends StatelessWidget {
  final List<Event> filteredEvents;
  final Function(String, DateTime?) onFilter;
  final Future<void> Function() onRefresh;

  EventView(
      {required this.filteredEvents,
      required this.onFilter,
      required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  onChanged: (value) => onFilter(value, null),
                  decoration: InputDecoration(
                    labelText: 'Search by Category',
                    suffixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
              IconButton(
                icon: Icon(Icons.calendar_today),
                onPressed: () async {
                  final date = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (date != null) {
                    onFilter('', date);
                  }
                },
                tooltip: 'Select Date',
              ),
            ],
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: onRefresh,
            child: SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              child: Column(
                children: filteredEvents.map((event) {
                  return GestureDetector(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DetailEventPage(event: event),
                      ),
                    ),
                    child: Card(
                      margin: EdgeInsets.all(8),
                      elevation: 5,
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: 100,
                            height: 100,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: NetworkImage(event.eventPoster),
                                fit: BoxFit.cover,
                              ),
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(4),
                                bottomLeft: Radius.circular(4),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              padding: EdgeInsets.all(10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    event.eventName,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  SizedBox(height: 5),
                                  Text(event.eventDate),
                                  SizedBox(height: 5),
                                  Text(
                                    event.eventCategory,
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontStyle: FontStyle.italic,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class OrderView extends StatelessWidget {
  final List<Pemesanan> filteredOrders;
  final List<Event> events;
  final List<User> users;
  final Function(String, DateTime?) onFilter;
  final PemesananDao pemesananDao;
  final Future<void> Function() onRefresh;

  OrderView({
    required this.filteredOrders,
    required this.events,
    required this.users,
    required this.onFilter,
    required this.pemesananDao,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            children: [
              Expanded(
                child: TextField(
                  onChanged: (value) => onFilter(value, null),
                  decoration: InputDecoration(
                    labelText: 'Search by Category',
                    suffixIcon: Icon(Icons.search),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
              IconButton(
                icon: Icon(Icons.calendar_today),
                onPressed: () async {
                  final date = await showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(2000),
                    lastDate: DateTime(2100),
                  );
                  if (date != null) {
                    onFilter('', date);
                  }
                },
                tooltip: 'Select Date',
              ),
            ],
          ),
        ),
        Expanded(
          child: RefreshIndicator(
            onRefresh: onRefresh,
            child: SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              child: Column(
                children: filteredOrders.map((order) {
                  final event =
                      events.firstWhere((e) => e.eventId == order.eventId);
                  final user =
                      users.firstWhere((u) => u.userId == order.userId);
                  return Dismissible(
                    key: Key(order.pemesananId),
                    direction: DismissDirection.endToStart,
                    background: Container(
                      color: Colors.red,
                      alignment: Alignment.centerRight,
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Icon(Icons.delete, color: Colors.white),
                    ),
                    confirmDismiss: (direction) async {
                      if (order.status == 'Pending') {
                        return await showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: Text('Batalkan Checkout'),
                              content: Text(
                                  'Apakah Anda yakin ingin membatalkan checkout?'),
                              actions: <Widget>[
                                TextButton(
                                  onPressed: () =>
                                      Navigator.of(context).pop(false),
                                  child: Text('Cancel'),
                                ),
                                TextButton(
                                  onPressed: () =>
                                      Navigator.of(context).pop(true),
                                  child: Text('Batalkan Checkout'),
                                ),
                              ],
                            );
                          },
                        );
                      } else {
                        await showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: Text('Tidak Bisa Dibatalkan'),
                              content: Text(
                                  'Data sudah diproses dan tidak bisa dibatalkan.'),
                              actions: <Widget>[
                                TextButton(
                                  onPressed: () =>
                                      Navigator.of(context).pop(false),
                                  child: Text('OK'),
                                ),
                              ],
                            );
                          },
                        );
                        return false;
                      }
                    },
                    onDismissed: (direction) async {
                      await pemesananDao.deletePemesanan(order);
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('Checkout dibatalkan')),
                      );
                      onFilter('', null); // Refresh the list
                    },
                    child: Card(
                      margin: EdgeInsets.all(8),
                      elevation: 5,
                      child: Row(
                        children: <Widget>[
                          Container(
                            width: 100,
                            height: 100,
                            decoration: BoxDecoration(
                              image: DecorationImage(
                                image: NetworkImage(event.eventPoster),
                                fit: BoxFit.cover,
                              ),
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(4),
                                bottomLeft: Radius.circular(4),
                              ),
                            ),
                          ),
                          Expanded(
                            child: Container(
                              padding: EdgeInsets.all(10),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    order.pemesananId,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                    maxLines: 2,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  SizedBox(height: 5),
                                  Text(
                                    event.eventName,
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontStyle: FontStyle.italic,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  Text(order.bookingDate
                                      .toString()
                                      .split(' ')[0]), // Formatted date
                                  SizedBox(height: 5),
                                  Text(
                                    user.fullName,
                                    style: TextStyle(
                                      fontSize: 14,
                                      fontStyle: FontStyle.italic,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                  SizedBox(height: 5),
                                  Text(
                                    "Status: ${order.status}",
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: _getStatusColor(order.status),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Approved':
        return Colors.green;
      case 'Rejected':
        return Colors.red;
      default:
        return Colors.orange;
    }
  }
}
