import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import '../../dao/user_dao.dart';
import '../../models/user_model.dart';

class RegisterPage extends StatefulWidget {
  @override
  _RegisterPageState createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final usernameController = TextEditingController();
  final fullNameController = TextEditingController();
  final nimController = TextEditingController();
  final phoneController = TextEditingController();
  final passwordController = TextEditingController();
  final UserDao userDao = UserDao();

  void _register() async {
    var user = User()
      ..userId = DateTime.now().millisecondsSinceEpoch.toString()
      ..username = usernameController.text
      ..fullName = fullNameController.text
      ..nim = nimController.text
      ..phone = phoneController.text
      ..password = passwordController.text;

    await userDao.addUser(user);

    // Navigate to login after registration
    Navigator.pushReplacementNamed(context, '/login');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.purple[700]!, Colors.deepPurple[900]!],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  'Create Account',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 20),
                _buildTextField(
                  controller: usernameController,
                  label: 'Username',
                  icon: Icons.person,
                ),
                SizedBox(height: 20),
                _buildTextField(
                  controller: fullNameController,
                  label: 'Full Name',
                  icon: Icons.badge,
                ),
                SizedBox(height: 20),
                _buildTextField(
                  controller: nimController,
                  label: 'NIM',
                  icon: Icons.school,
                ),
                SizedBox(height: 20),
                _buildTextField(
                  controller: phoneController,
                  label: 'Phone (WA)',
                  icon: Icons.phone,
                ),
                SizedBox(height: 20),
                _buildTextField(
                  controller: passwordController,
                  label: 'Password',
                  icon: Icons.lock,
                  isPassword: true,
                ),
                SizedBox(height: 40),
                ElevatedButton(
                  style: ButtonStyle(
                    backgroundColor: MaterialStateProperty.all(Colors.white),
                    foregroundColor:
                        MaterialStateProperty.all(Colors.deepPurple.shade700),
                    padding: MaterialStateProperty.all(
                        EdgeInsets.symmetric(vertical: 15, horizontal: 50)),
                    textStyle:
                        MaterialStateProperty.all(TextStyle(fontSize: 16)),
                    shape: MaterialStateProperty.all(RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12))),
                    elevation: MaterialStateProperty.all(8),
                    shadowColor:
                        MaterialStateProperty.all(Colors.deepPurple.shade200),
                  ),
                  onPressed: _register,
                  child: Text('Register'),
                ),
                SizedBox(height: 20),
                GestureDetector(
                  onTap: () {
                    Navigator.pushNamed(
                        context, '/login'); // Navigate to login page
                  },
                  child: Text(
                    'Have an account? Login here.',
                    style: TextStyle(
                      color: Colors.white70,
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool isPassword = false,
  }) {
    return TextField(
      controller: controller,
      obscureText: isPassword,
      style: TextStyle(fontSize: 16, color: Colors.white70),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: Colors.white70),
        prefixIcon: Icon(icon, color: Colors.white70),
        filled: true,
        fillColor: Colors.deepPurple.shade300.withOpacity(0.3),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.white70),
        ),
      ),
    );
  }
}
