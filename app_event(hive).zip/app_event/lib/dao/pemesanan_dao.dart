import 'package:hive/hive.dart';
import '../models/pemesanan_model.dart';

class PemesananDao {
  final Box<Pemesanan> _pemesananBox = Hive.box<Pemesanan>('pemesananBox');

  Future<void> addPemesanan(Pemesanan pemesanan) async {
    await _pemesananBox.add(pemesanan);
  }

  List<Pemesanan> getAllPemesanans() {
    return _pemesananBox.values.toList();
  }

  Pemesanan? getPemesananById(String pemesananId) {
    final pemesanans = _pemesananBox.values
        .where((pemesanan) => pemesanan.pemesananId == pemesananId);
    return pemesanans.isNotEmpty ? pemesanans.first : null;
  }

  Future<void> updatePemesanan(Pemesanan pemesanan) async {
    pemesanan.save();
  }

  Future<void> deletePemesanan(Pemesanan pemesanan) async {
    await pemesanan.delete();
  }
}
