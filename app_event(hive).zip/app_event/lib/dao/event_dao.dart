import 'package:hive/hive.dart';
import '../models/event_model.dart';

class EventDao {
  final Box<Event> _eventBox = Hive.box<Event>('eventBox');

  Future<void> addEvent(Event event) async {
    await _eventBox.add(event);
  }

  List<Event> getAllEvents() {
    return _eventBox.values.toList();
  }

  Event? getEventById(String eventId) {
    final events = _eventBox.values.where((event) => event.eventId == eventId);
    return events.isNotEmpty ? events.first : null;
  }

  Future<void> updateEvent(Event event) async {
    event.save();
  }

  Future<void> deleteEvent(Event event) async {
    await event.delete();
  }
}
