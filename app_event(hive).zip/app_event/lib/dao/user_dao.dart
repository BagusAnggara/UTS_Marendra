import 'package:hive/hive.dart';
import '../models/user_model.dart';

class UserDao {
  final Box<User> _userBox = Hive.box<User>('userBox');

  Future<void> addUser(User user) async {
    await _userBox.add(user);
  }

  List<User> getAllUsers() {
    return _userBox.values.toList();
  }

  User? getUserById(String userId) {
    final users = _userBox.values.where((user) => user.userId == userId);
    return users.isNotEmpty ? users.first : null;
  }

  Future<void> updateUser(User user) async {
    user.save();
  }

  Future<void> deleteUser(User user) async {
    await user.delete();
  }
}
