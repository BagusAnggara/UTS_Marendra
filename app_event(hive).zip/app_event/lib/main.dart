import 'package:flutter/material.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'models/user_model.dart';
import 'models/event_model.dart';
import 'models/pemesanan_model.dart';
import 'pages/auth/login_page.dart';
import 'pages/auth/register_page.dart';
import 'pages/home/home_view.dart';
import 'dummy_event.dart'; // Import dummy_event.dart

void main() async {
  await Hive.initFlutter();
  Hive.registerAdapter(UserAdapter());
  Hive.registerAdapter(EventAdapter());
  Hive.registerAdapter(PemesananAdapter());
  await Hive.openBox<User>('userBox');
  var eventBox = await Hive.openBox<Event>('eventBox');
  await Hive.openBox<Pemesanan>('pemesananBox');

  // Tambahkan data dummy jika eventBox kosong
  if (eventBox.isEmpty) {
    var dummyEvents = getDummyEvents();
    for (var event in dummyEvents) {
      await eventBox.add(event);
    }
  }

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      initialRoute: '/login',
      routes: {
        '/login': (context) => LoginPage(),
        '/register': (context) => RegisterPage(),
        '/home': (context) => HomeView(),
      },
      home: LoginPage(),
    );
  }
}
