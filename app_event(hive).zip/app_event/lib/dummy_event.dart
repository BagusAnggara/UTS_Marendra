import 'models/event_model.dart';

List<Event> getDummyEvents() {
  return [
    Event()
      ..eventId = '1'
      ..eventName = 'Seminar Teknologi AI'
      ..eventDate = '2024-07-10'
      ..eventLocation = 'Aula Utama Kampus'
      ..eventPoster =
          'https://img.freepik.com/free-psd/modern-technology-conference-poster-template_23-2148983074.jpg'
      ..eventDescription =
          'Seminar tentang perkembangan teknologi AI di Indonesia.'
      ..eventCategory = 'Teknologi',
    Event()
      ..eventId = '2'
      ..eventName = 'Workshop Desain Grafis'
      ..eventDate = '2024-07-11'
      ..eventLocation = 'Ruang Multimedia'
      ..eventPoster =
          'https://img.freepik.com/free-psd/design-conference-poster-template_53876-66223.jpg'
      ..eventDescription =
          'Workshop untuk mempelajari teknik dasar desain grafis.'
      ..eventCategory = 'Desain',
    Event()
      ..eventId = '3'
      ..eventName = 'Lomba Debat Mahasiswa'
      ..eventDate = '2024-07-12'
      ..eventLocation = 'Aula Fakultas Hukum'
      ..eventPoster =
          'https://img.freepik.com/free-psd/modern-debate-contest-poster-template_23-2148786911.jpg'
      ..eventDescription =
          'Kompetisi debat antar mahasiswa dari berbagai fakultas.'
      ..eventCategory = 'Kompetisi',
    Event()
      ..eventId = '4'
      ..eventName = 'Pameran Seni Mahasiswa'
      ..eventDate = '2024-07-13'
      ..eventLocation = 'Galeri Seni Kampus'
      ..eventPoster =
          'https://img.freepik.com/free-psd/art-exhibition-event-poster-template_23-2148796520.jpg'
      ..eventDescription =
          'Pameran karya seni mahasiswa dari fakultas seni rupa.'
      ..eventCategory = 'Seni',
    Event()
      ..eventId = '5'
      ..eventName = 'Konser Musik Kampus'
      ..eventDate = '2024-07-14'
      ..eventLocation = 'Lapangan Kampus'
      ..eventPoster =
          'https://img.freepik.com/free-psd/music-concert-poster-template_23-2148788541.jpg'
      ..eventDescription =
          'Konser musik yang menampilkan band-band kampus terbaik.'
      ..eventCategory = 'Musik',
  ];
}
